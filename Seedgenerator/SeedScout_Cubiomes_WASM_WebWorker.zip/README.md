# SeedScout – Cubiomes WASM + WebWorker

## Was ist enthalten?
- vollständige UI
- Java/Version/Kriterien
- Seed-Bereich
- WebWorker für die Suche
- Fortschritt/Stop/Matches
- echte WASM-Ladeschnittstelle

## Warum liegen cubiomes.js/.wasm nicht hier?
Die Binärdateien müssen aus dem passenden Cubiomes/xpple-Cubiomes-Stand für die gewünschte Minecraft-Version gebaut werden. Ein blind eingebundener älterer Build würde 26.1.2 nicht korrekt repräsentieren.

## Erwartete Engine-API
`public/wasm/cubiomes.js` muss als Emscripten-Modul eine Funktion liefern:

`findMatch(seedString, criteria) -> { match: boolean, summary?: string }`

Diese Funktion kapselt:
1. Generator auf die gewählte Java-Version setzen.
2. Seed anwenden.
3. Weltspawn bestimmen.
4. Biome im angegebenen Radius prüfen.
5. gewünschte Strukturen im Radius prüfen.
6. `match` zurückgeben.

## WebWorker
`src/worker.js` führt alle Engine-Aufrufe außerhalb des UI-Threads aus.

## Build
Vite reicht:
`npm install`
`npm run dev`

Für Hosting müssen die WASM-Dateien unter `/wasm/` verfügbar sein. Bei Threads SharedArrayBuffer/Cross-Origin-Isolation beachten.

## Versionshinweis
Cubiomes ist primär eine Java-Worldgen-Bibliothek. Eine öffentlich dokumentierte Webapp, Seeder, nutzt Cubiomes-WASM und unterstützt inzwischen Java bis 26.2. Bedrock ist eine separate Worldgen-Frage und sollte nicht als Java-Ergebnis ausgegeben werden.
