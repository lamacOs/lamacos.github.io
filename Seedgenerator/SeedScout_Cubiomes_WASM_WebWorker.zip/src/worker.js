let stopped=false;
let api=null;
async function init(){
 try{
   importScripts?.();
 }catch{}
 try{
   // Emscripten module expected at /wasm/cubiomes.js.
   const mod=await import("/wasm/cubiomes.js");
   api=await mod.default();
   postMessage({type:"ready"});
 }catch(e){
   postMessage({type:"error",message:"cubiomes.js/.wasm fehlt. Lege den mit Emscripten erzeugten WASM-Build unter public/wasm/ ab."});
 }
}
self.onmessage=async e=>{
 const m=e.data;
 if(m.type==="init"){init();return}
 if(m.type==="stop"){stopped=true;return}
 if(m.type!=="search")return;
 if(!api){postMessage({type:"error",message:"WASM-Engine ist nicht geladen."});return}
 stopped=false;
 // The generated binding below expects a small JS API wrapper exported by the WASM build.
 // Search is intentionally isolated in the worker so the UI never freezes.
 const total=m.count,start=BigInt(m.start),t0=performance.now();
 for(let i=0;i<total&&!stopped;i++){
   const seed=(start+BigInt(i)).toString();
   let r;
   try{r=api.findMatch(seed,m.criteria)}catch(err){postMessage({type:"error",message:String(err)});return}
   if(r?.match)postMessage({type:"match",seed,summary:r.summary});
   if(i%500===0||i===total-1){
     const sec=(performance.now()-t0)/1000;
     postMessage({type:"progress",done:i+1,total,percent:(i+1)/total*100,rate:Math.round((i+1)/Math.max(sec,.001))});
     await new Promise(r=>setTimeout(r,0));
   }
 }
 postMessage({type:"done",message:stopped?"Suche gestoppt.":"Suche beendet."});
};
