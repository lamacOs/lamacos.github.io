package de.lamacos.linkup;

import net.fabricmc.loader.api.FabricLoader;

import javax.imageio.ImageIO;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/** Local-only cosmetics library. No account, network service or database is used. */
public final class CosmeticsManager {
    private static final Path ROOT = FabricLoader.getInstance().getConfigDir().resolve("linkupclient/cosmetics");
    private static final Path SKINS = ROOT.resolve("skins");
    private static final Path CAPES = ROOT.resolve("capes");
    private static final Path SETTINGS = ROOT.resolve("selected.properties");
    private static final Properties selected = new Properties();

    private CosmeticsManager() {}

    public static void initialize() {
        try {
            Files.createDirectories(SKINS);
            Files.createDirectories(CAPES);
            if (Files.exists(SETTINGS)) {
                try (var in = Files.newInputStream(SETTINGS)) { selected.load(in); }
            }
        } catch (IOException e) {
            System.err.println("[LinkUp] Cosmetics-Ordner konnte nicht vorbereitet werden: " + e.getMessage());
        }
    }

    public static Path directory() { initialize(); return ROOT; }
    public static String selectedSkin() { return selected.getProperty("skin", "(keiner ausgewählt)"); }
    public static String selectedCape() { return selected.getProperty("cape", "(keiner ausgewählt)"); }

    public static boolean importSkin() { return importImage(true); }
    public static boolean importCape() { return importImage(false); }

    private static boolean importImage(boolean skin) {
        if (GraphicsEnvironment.isHeadless()) return false;
        FileDialog dialog = new FileDialog((Frame) null, skin ? "Minecraft-Skin auswählen" : "Cape auswählen", FileDialog.LOAD);
        dialog.setFile("*.png");
        dialog.setVisible(true);
        if (dialog.getFile() == null) return false;
        Path source = Path.of(dialog.getDirectory(), dialog.getFile());
        try {
            BufferedImage image = ImageIO.read(source.toFile());
            if (image == null) return false;
            boolean valid = skin
                    ? image.getWidth() == 64 && (image.getHeight() == 64 || image.getHeight() == 32)
                    : image.getWidth() == 64 && image.getHeight() == 32;
            if (!valid) return false;
            Path folder = skin ? SKINS : CAPES;
            Files.createDirectories(folder);
            String filename = source.getFileName().toString().replaceAll("[^A-Za-z0-9._-]", "_");
            if (!filename.toLowerCase().endsWith(".png")) filename += ".png";
            Path destination = folder.resolve(filename);
            Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
            selected.setProperty(skin ? "skin" : "cape", filename);
            save();
            return true;
        } catch (IOException e) {
            System.err.println("[LinkUp] Cosmetics-Import fehlgeschlagen: " + e.getMessage());
            return false;
        }
    }

    public static void chooseSkin(String filename) { choose("skin", SKINS, filename); }
    public static void chooseCape(String filename) { choose("cape", CAPES, filename); }
    private static void choose(String key, Path folder, String filename) {
        if (filename != null && Files.isRegularFile(folder.resolve(filename))) {
            selected.setProperty(key, filename);
            save();
        }
    }
    private static void save() {
        try {
            Files.createDirectories(ROOT);
            try (var out = Files.newOutputStream(SETTINGS)) { selected.store(out, "LinkUp Client local cosmetics selection"); }
        } catch (IOException e) {
            System.err.println("[LinkUp] Cosmetics-Auswahl konnte nicht gespeichert werden: " + e.getMessage());
        }
    }
}
