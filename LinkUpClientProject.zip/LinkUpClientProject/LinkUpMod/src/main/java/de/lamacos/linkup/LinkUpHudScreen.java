
package de.lamacos.linkup;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class LinkUpHudScreen extends Screen {

    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir()
                    .resolve("linkupclient-hud.txt");

    private static final int HUD_WIDTH = 148;
    private static final int HUD_HEIGHT = 78;

    private static int hudX = 12;
    private static int hudY = 12;
    private static boolean editingMode = false;
    private static boolean hudVisible = true;

    private boolean dragging;
    private double dragOffsetX;
    private double dragOffsetY;

    public LinkUpHudScreen() {
        super(Component.literal("LinkUp HUD"));
        loadSavedPosition();
    }

    public static boolean isEditingMode() {
        return editingMode;
    }

    public static void setEditingMode(boolean editing) {
        editingMode = editing;
    }

    public static boolean isHudVisible() {
        return hudVisible;
    }

    public static void setHudVisible(boolean visible) {
        hudVisible = visible;
    }

    public static void resetPosition() {
        hudX = 12;
        hudY = 12;
        savePosition();
    }

    public static void renderHud(
            GuiGraphicsExtractor graphics,
            Minecraft client,
            boolean editing
    ) {
        if (!hudVisible && !editing) {
            return;
        }

        int x = hudX;
        int y = hudY;

        graphics.fill(
                x, y, x + HUD_WIDTH, y + HUD_HEIGHT,
                0xE8171B25
        );

        graphics.fill(
                x, y, x + HUD_WIDTH, y + 2,
                0xFF01C7FC
        );

        if (editing) {
            graphics.fill(
                    x, y + HUD_HEIGHT - 2,
                    x + HUD_WIDTH, y + HUD_HEIGHT,
                    0xFF01C7FC
            );
        }

        graphics.text(
                client.font,
                "LinkUp HUD",
                x + 8, y + 7,
                0xFF01C7FC, true
        );

        if (client.player == null) {
            graphics.text(
                    client.font,
                    "Keine Welt geladen",
                    x + 8, y + 25,
                    0xFFFFFFFF, false
            );
            return;
        }

        var player = client.player;

        graphics.text(
                client.font,
                String.format(
                        "XYZ: %d / %d / %d",
                        (int) Math.floor(player.getX()),
                        (int) Math.floor(player.getY()),
                        (int) Math.floor(player.getZ())
                ),
                x + 8, y + 25,
                0xFFFFFFFF, false
        );

        graphics.text(
                client.font,
                "Chunk: " + player.chunkPosition().x()
                        + ", " + player.chunkPosition().z(),
                x + 8, y + 37,
                0xFFE6EAF0, false
        );

        int ping = -1;

        if (client.getConnection() != null) {
            var info = client.getConnection()
                    .getPlayerInfo(player.getUUID());

            if (info != null) {
                ping = info.getLatency();
            }
        }

        graphics.text(
                client.font,
                "Ping: " + (ping < 0 ? "--" : ping + " ms"),
                x + 8, y + 49,
                0xFFE6EAF0, false
        );

        graphics.text(
                client.font,
                "Richtung: " + directionName(
                        player.getDirection()
                ),
                x + 8, y + 61,
                0xFFE6EAF0, false
        );

        graphics.text(
                client.font,
                editing ? "Ziehen | J: Fixieren" : "LinkUp Client",
                x + 8, y + 65,
                0xFF9CA3AF, false
        );
    }

    private static String directionName(Direction direction) {
        return switch (direction) {
            case NORTH -> "Norden";
            case SOUTH -> "Süden";
            case EAST -> "Osten";
            case WEST -> "Westen";
            default -> "Unbekannt";
        };
    }

    @Override
    public void extractRenderState(
            GuiGraphicsExtractor graphics,
            int mouseX,
            int mouseY,
            float delta
    ) {
        renderHud(graphics, Minecraft.getInstance(), true);
        super.extractRenderState(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(
            MouseButtonEvent event,
            boolean doubleClick
    ) {
        double mouseX = event.x();
        double mouseY = event.y();

        if (event.button() == 0
                && mouseX >= hudX - 6
                && mouseX <= hudX + HUD_WIDTH + 6
                && mouseY >= hudY - 6
                && mouseY <= hudY + HUD_HEIGHT + 6) {

            dragging = true;
            dragOffsetX = mouseX - hudX;
            dragOffsetY = mouseY - hudY;
            return true;
        }

        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(
            MouseButtonEvent event,
            double mouseX,
            double mouseY
    ) {
        if (dragging && event.button() == 0) {
            hudX = Math.max(
                    0,
                    Math.min(
                            (int) (mouseX - dragOffsetX),
                            Math.max(0, width - HUD_WIDTH)
                    )
            );

            hudY = Math.max(
                    0,
                    Math.min(
                            (int) (mouseY - dragOffsetY),
                            Math.max(0, height - HUD_HEIGHT)
                    )
            );

            return true;
        }

        return super.mouseDragged(event, mouseX, mouseY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (event.button() == 0 && dragging) {
            dragging = false;
            savePosition();
            return true;
        }

        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        dragging = false;
        editingMode = false;
        savePosition();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    public static void loadSavedPosition() {
        try {
            if (!Files.exists(FILE)) {
                return;
            }

            List<String> lines = Files.readAllLines(FILE);

            if (lines.size() >= 2) {
                hudX = Integer.parseInt(lines.get(0));
                hudY = Integer.parseInt(lines.get(1));
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println(
                    "[LinkUp Client] HUD-Position konnte nicht geladen werden."
            );
        }
    }

    private static void savePosition() {
        try {
            Files.createDirectories(FILE.getParent());

            Files.write(
                    FILE,
                    List.of(
                            Integer.toString(hudX),
                            Integer.toString(hudY)
                    )
            );
        } catch (IOException e) {
            System.err.println(
                    "[LinkUp Client] HUD-Position konnte nicht gespeichert werden."
            );
        }
    }
}
