# LinkUp Client – Cosmetics-Stand (lokal)

## In diesem Quellstand enthalten
- Lokaler Cosmetics-Ordner unter `config/linkupclient/cosmetics/`
- Import von Skin-PNG-Dateien (64x64 oder Legacy 64x32)
- Import von Cape-PNG-Dateien (64x32)
- Lokale Speicherung der ausgewählten Dateinamen in `selected.properties`
- Cosmetics-Seite im Rechts-Shift-Menü
- Öffnen des Cosmetics-Ordners
- HUD-Größe auf 148x78 reduziert; Drag-Hitbox um 6 GUI-Pixel erweitert; Footer innerhalb der HUD-Fläche positioniert

## Bewusst noch nicht als fertig behauptet
Dieser Stand enthält noch KEIN Rendering der importierten Skin-Textur auf dem eigenen Player-Modell und KEIN Cape-Rendering auf Player-Renderern. Auch eine Chat-Synchronisierung zu anderen LinkUp-Clients ist noch nicht implementiert. Dafür sind Minecraft-26.3-Renderer-/Skin-Manager-Integrationen und ein sauber spezifiziertes Chat-Protokoll nötig. Ein einfacher sichtbarer Chatbefehl wäre kein verlässlicher Ersatz und könnte von Servern blockiert werden.

Es werden keine fremden Texturen mitgeliefert. Importierte Dateien müssen vom Nutzer rechtmäßig verwendet werden dürfen. Es gibt keine Datenbank und keinen Cosmetics-Account.

## Build / Test
Zielversion: Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.162.0+26.3, Java 25.
Der Quellstand wurde in dieser Umgebung nicht kompiliert oder im Spiel gestartet, da nur Java 21 verfügbar war. Bitte vor Nutzung mit Java 25 bauen und in einer Testinstanz prüfen.
