# LinkUp Client – Implementierungsstand

## In dieser Arbeitsfassung umgesetzt
- HUD kompakter gemacht (148 × 68 statt 148 × 78) und Textpositionen innerhalb der Fläche korrigiert.
- HUD-Maus-Hitbox auf 12 Pixel Rand erweitert.
- J-Taste öffnet den HUD-Editor nicht mehr blind über beliebige andere Screens.
- Lokaler Cosmetics-Dateimanager ohne Konto und ohne Datenbank.
- Skin- und Cape-PNG-Dateien können über Dateiauswahl importiert werden.
- Importierte Dateien werden getrennt in `config/linkupclient/cosmetics/skins` und `.../capes` gespeichert.
- Skin-/Cape-Auswahl wird lokal in `selection.properties` gespeichert.
- Cosmetics-Menü zeigt lokale Dateien und erlaubt Auswahl.

## Noch nicht umgesetzt (wird ausdrücklich nicht als fertig ausgegeben)
- Skin-Textur live auf das eigene Spielermodell anwenden.
- Cape-Textur auf Spieler rendern.
- Zusätzliche 3D-Accessoires.
- Cosmetics zwischen Clients über Minecraft-Chat synchronisieren. Das erfordert ein robustes, serververträgliches Nachrichtenprotokoll und einen Renderer auf Empfängerseite. Ein einfacher Chattext allein rendert keine Cosmetics.
- Lizenzgeprüfter, mitgelieferter Drittanbieter-Katalog. In diesem Paket werden keine fremden Skins/Capes ohne nachgewiesene Einzel-Lizenz beigelegt.

## Build / Test
- Ziel: Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.162.0+26.3, Java 25.
- Diese Umgebung hat Java 21. Daher wurde kein erfolgreicher Java-25-Gradle-Build behauptet.
- Die Quelltextänderungen wurden vorgenommen, aber nicht im Spiel getestet.

## Lokale Dateiformate
- Skins: PNG, Minecraft-Skin-Layout wird für den Import noch nicht auf Modellkompatibilität geprüft.
- Capes: PNG wird gespeichert; Bildabmessungen/Renderformat werden noch nicht validiert.
