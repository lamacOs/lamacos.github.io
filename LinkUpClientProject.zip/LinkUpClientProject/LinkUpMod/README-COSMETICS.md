# LinkUp Cosmetics (local foundation)

- No database, account, or remote service.
- Open Right Shift > Cosmetics, then use "Cosmetics-Ordner öffnen".
- Local folder: `.minecraft/config/linkupclient/cosmetics/`
  - `skins/`: reserved for compatible skin PNGs
  - `capes/`: original sample cape textures are bundled in the mod resources
- Three original CC0 cape designs are included.

## Status
This update adds the Cosmetics page and local asset/catalog foundation. It
also reduces the HUD to 148x78 and expands its mouse hit area by 6 px. The
J key remains the edit-mode toggle.

The textures are not yet rendered on player models; the selected cosmetic is
not synchronized to other LinkUp users. A chat-command bridge would require
server-side message forwarding and a client receiver. This archive does not
claim those parts are complete.

Build requires Java 25 and the project's Gradle wrapper. Run `./gradlew build`.
