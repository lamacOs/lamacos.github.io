
package de.lamacos.linkup;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.awt.Desktop;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class LinkUpMenuScreen extends Screen {

    private enum Page {
        MODS,
        SETTINGS,
        PROFILES,
        PACKS,
        FILES
    }

    private Page currentPage = Page.MODS;
    private int scrollOffset = 0;

    public LinkUpMenuScreen() {
        super(Component.literal("LinkUp Client"));
    }

    private List<ModContainer> getMods() {
        return FabricLoader.getInstance()
                .getAllMods()
                .stream()
                .sorted(Comparator.comparing(
                        mod -> mod.getMetadata().getName(),
                        String.CASE_INSENSITIVE_ORDER
                ))
                .toList();
    }

    @Override
    protected void init() {
        clearWidgets();

        int margin = 24;
        int gap = 6;
        int availableWidth = Math.max(270, width - margin * 2);
        int buttonWidth = (availableWidth - gap * 4) / 5;
        int tabY = 48;

        addTab("Mods", Page.MODS, margin, tabY, buttonWidth);

        addTab(
                "Settings",
                Page.SETTINGS,
                margin + buttonWidth + gap,
                tabY,
                buttonWidth
        );

        addTab(
                "Profile",
                Page.PROFILES,
                margin + (buttonWidth + gap) * 2,
                tabY,
                buttonWidth
        );

        addTab(
                "Packs",
                Page.PACKS,
                margin + (buttonWidth + gap) * 3,
                tabY,
                buttonWidth
        );

        addTab(
                "Ordner",
                Page.FILES,
                margin + (buttonWidth + gap) * 4,
                tabY,
                buttonWidth
        );

        addRenderableWidget(
                Button.builder(
                        Component.literal("Schließen"),
                        button -> onClose()
                ).bounds(
                        width / 2 - 60,
                        height - 32,
                        120,
                        20
                ).build()
        );

        if (currentPage == Page.SETTINGS) {
            addRenderableWidget(
                    Button.builder(
                            Component.literal(
                                    "HUD: " + (
                                            LinkUpHudScreen.isHudVisible()
                                                    ? "Ein"
                                                    : "Aus"
                                    )
                            ),
                            button -> {
                                LinkUpHudScreen.setHudVisible(
                                        !LinkUpHudScreen.isHudVisible()
                                );
                                init();
                            }
                    ).bounds(
                            32, 100, 180, 22
                    ).build()
            );

            addRenderableWidget(
                    Button.builder(
                            Component.literal(
                                    "HUD-Position zurücksetzen"
                            ),
                            button -> LinkUpHudScreen.resetPosition()
                    ).bounds(
                            32, 132, 210, 22
                    ).build()
            );
        }

        if (currentPage == Page.FILES) {
            addRenderableWidget(
                    Button.builder(
                            Component.literal(
                                    "Konfigurationsordner öffnen"
                            ),
                            button -> openConfigFolder()
                    ).bounds(
                            32, 100, 220, 22
                    ).build()
            );
        }
    }

    private void addTab(
            String label,
            Page page,
            int x,
            int y,
            int buttonWidth
    ) {
        addRenderableWidget(
                Button.builder(
                        Component.literal(
                                currentPage == page
                                        ? "> " + label
                                        : label
                        ),
                        button -> {
                            currentPage = page;
                            scrollOffset = 0;
                            init();
                        }
                ).bounds(
                        x, y, buttonWidth, 22
                ).build()
        );
    }

    private void openConfigFolder() {
        try {
            if (!Desktop.isDesktopSupported()) {
                System.err.println(
                        "[LinkUp Client] Desktop-Funktionen "
                                + "werden nicht unterstützt."
                );
                return;
            }

            Desktop.getDesktop().open(
                    FabricLoader.getInstance()
                            .getConfigDir()
                            .toFile()
            );
        } catch (IOException | UnsupportedOperationException e) {
            System.err.println(
                    "[LinkUp Client] Konfigurationsordner "
                            + "konnte nicht geöffnet werden: "
                            + e.getMessage()
            );
        }
    }

    @Override
    public void extractRenderState(
            GuiGraphicsExtractor graphics,
            int mouseX,
            int mouseY,
            float delta
    ) {
        // Hintergrund vor den Buttons zeichnen.
        graphics.fill(
                12, 12,
                width - 12, height - 12,
                0xE8171B25
        );

        graphics.fill(
                12, 12,
                width - 12, 15,
                0xFF01C7FC
        );

        super.extractRenderState(
                graphics,
                mouseX,
                mouseY,
                delta
        );

        graphics.text(
                font,
                "LinkUp Client",
                24, 22,
                0xFF01C7FC,
                true
        );

        switch (currentPage) {
            case MODS -> renderMods(graphics);
            case SETTINGS -> renderSettings(graphics);
            case PROFILES -> renderProfiles(graphics);
            case PACKS -> renderPacks(graphics);
            case FILES -> renderFiles(graphics);
        }
    }

    private void renderMods(GuiGraphicsExtractor graphics) {
        List<ModContainer> mods = getMods();

        graphics.text(
                font,
                "Installierte Mods: " + mods.size(),
                24, 78,
                0xFFFFFFFF,
                true
        );

        int startY = 98;
        int rowHeight = 12;
        int visibleRows = Math.max(
                1,
                (height - 150) / rowHeight
        );

        for (int i = 0; i < visibleRows; i++) {
            int index = scrollOffset + i;

            if (index >= mods.size()) {
                break;
            }

            ModContainer mod = mods.get(index);

            String name = mod.getMetadata().getName();
            String id = mod.getMetadata().getId();

            graphics.text(
                    font,
                    name + "  [" + id + "]",
                    28,
                    startY + i * rowHeight,
                    0xFFE6EAF0,
                    false
            );
        }

        graphics.text(
                font,
                "Mausrad: Liste scrollen",
                24,
                height - 48,
                0xFF9CA3AF,
                false
        );
    }

    private void renderSettings(
            GuiGraphicsExtractor graphics
    ) {
        graphics.text(
                font,
                "Client-Einstellungen",
                24, 80,
                0xFFFFFFFF,
                true
        );

        graphics.text(
                font,
                "HUD sichtbar: " + (
                        LinkUpHudScreen.isHudVisible()
                                ? "Ja"
                                : "Nein"
                ),
                32, 168,
                0xFFE6EAF0,
                false
        );

        graphics.text(
                font,
                "Drücke J, um das HUD zu verschieben oder zu fixieren.",
                32, 190,
                0xFF9CA3AF,
                false
        );
    }

    private void renderProfiles(
            GuiGraphicsExtractor graphics
    ) {
        graphics.text(
                font,
                "Profile",
                24, 82,
                0xFFFFFFFF,
                true
        );

        graphics.text(
                font,
                "Minecraft-Startprofile verwaltest du über den Launcher.",
                32, 106,
                0xFFE6EAF0,
                false
        );

        graphics.text(
                font,
                "Änderungen an Mods können einen Neustart erfordern.",
                32, 126,
                0xFF9CA3AF,
                false
        );
    }

    private void renderPacks(
            GuiGraphicsExtractor graphics
    ) {
        graphics.text(
                font,
                "Resourcepacks und Shader",
                24, 82,
                0xFFFFFFFF,
                true
        );

        graphics.text(
                font,
                "Resourcepacks: Optionen > Ressourcenpakete",
                32, 106,
                0xFFE6EAF0,
                false
        );

        graphics.text(
                font,
                "Shader: Einstellungen des installierten Shader-Mods",
                32, 128,
                0xFFE6EAF0,
                false
        );

        graphics.text(
                font,
                "öffnen, zum Beispiel Iris, falls installiert.",
                32, 142,
                0xFFE6EAF0,
                false
        );
    }

    private void renderFiles(
            GuiGraphicsExtractor graphics
    ) {
        graphics.text(
                font,
                "LinkUp-Dateien",
                24, 82,
                0xFFFFFFFF,
                true
        );

        graphics.text(
                font,
                "Konfigurationsordner:",
                32, 126,
                0xFFE6EAF0,
                false
        );

        graphics.text(
                font,
                FabricLoader.getInstance()
                        .getConfigDir()
                        .toString(),
                32, 144,
                0xFF01C7FC,
                false
        );
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double horizontalAmount,
            double verticalAmount
    ) {
        if (currentPage != Page.MODS) {
            return super.mouseScrolled(
                    mouseX,
                    mouseY,
                    horizontalAmount,
                    verticalAmount
            );
        }

        int visibleRows = Math.max(
                1,
                (height - 150) / 12
        );

        int maxOffset = Math.max(
                0,
                getMods().size() - visibleRows
        );

        if (verticalAmount < 0) {
            scrollOffset = Math.min(
                    maxOffset,
                    scrollOffset + 3
            );
        } else if (verticalAmount > 0) {
            scrollOffset = Math.max(
                    0,
                    scrollOffset - 3
            );
        }

        return true;
    }

    @Override
    public void onClose() {
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
