
package de.lamacos.linkup;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class HotbarLayoutManager {

    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir()
                    .resolve("linkupclient-hotbar.txt");

    private static final int HOTBAR_SIZE = 9;
    private static final int INVENTORY_SIZE = 36;

    private static final List<String> layout =
            new ArrayList<>(Arrays.asList(
                    "sword", "axe", "pickaxe",
                    "food", "water", "blocks",
                    "pearls", "empty", "shovel"
            ));

    private HotbarLayoutManager() {
    }

    public static void save(Player player) {
        for (int i = 0; i < HOTBAR_SIZE; i++) {
            layout.set(i, classify(player.getInventory().getItem(i)));
        }

        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, layout);
            player.sendSystemMessage(
                    Component.literal("LinkUp Client: Hotbar gespeichert.")
            );
        } catch (IOException e) {
            player.sendSystemMessage(
                    Component.literal("LinkUp Client: Speichern fehlgeschlagen.")
            );
            e.printStackTrace();
        }
    }

    public static void load() {
        try {
            if (!Files.exists(FILE)) {
                return;
            }

            List<String> saved = Files.readAllLines(FILE);
            if (saved.size() != HOTBAR_SIZE) {
                return;
            }

            for (int i = 0; i < HOTBAR_SIZE; i++) {
                layout.set(i, saved.get(i).trim().toLowerCase(Locale.ROOT));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void apply(Player player) {
        Minecraft client = Minecraft.getInstance();

        if (client.player == null || client.player != player
                || client.gameMode == null) {
            return;
        }

        // Sortierung nur im normalen Spielerinventar ausführen.
        if (player.containerMenu.containerId != 0) {
            player.sendSystemMessage(Component.literal(
                    "LinkUp Client: Schließe zuerst das geöffnete Inventar-Menü."
            ));
            return;
        }

        boolean[] locked = new boolean[HOTBAR_SIZE];
        int changed = 0;
        int missing = 0;

        for (int target = 0; target < HOTBAR_SIZE; target++) {
            String wanted = layout.get(target);
            ItemStack current = player.getInventory().getItem(target);

            if (matchesCategory(current, wanted)) {
                locked[target] = true;
                continue;
            }

            int source = findSource(player, wanted, target, locked);

            if (source == -1) {
                missing++;
                continue;
            }

            int menuSlot = inventoryIndexToMenuSlot(source);

            // Normale Inventaraktion, die auch an den Server gesendet wird.
            client.gameMode.handleContainerInput(
                    player.containerMenu.containerId,
                    menuSlot,
                    target,
                    ContainerInput.SWAP,
                    player
            );

            locked[target] = true;
            changed++;
        }

        player.sendSystemMessage(Component.literal(
                "LinkUp Client: Sortierung abgeschlossen. Aktionen: "
                        + changed + ", nicht erfüllte Slots: " + missing
        ));
    }

    private static int findSource(
            Player player,
            String wanted,
            int target,
            boolean[] locked
    ) {
        // Zuerst andere Hotbar-Slots prüfen.
        for (int source = 0; source < HOTBAR_SIZE; source++) {
            if (source == target || locked[source]) {
                continue;
            }

            if (matchesCategory(
                    player.getInventory().getItem(source), wanted)) {
                return source;
            }
        }

        // Danach das restliche Inventar prüfen.
        for (int source = HOTBAR_SIZE; source < INVENTORY_SIZE; source++) {
            if (matchesCategory(
                    player.getInventory().getItem(source), wanted)) {
                return source;
            }
        }

        return -1;
    }

    private static int inventoryIndexToMenuSlot(int index) {
        // Menü-Slots 36–44 sind die neun Hotbar-Slots.
        if (index >= 0 && index < HOTBAR_SIZE) {
            return 36 + index;
        }

        // Menü-Slots 9–35 sind das normale Inventar.
        if (index >= HOTBAR_SIZE && index < INVENTORY_SIZE) {
            return index;
        }

        throw new IllegalArgumentException(
                "Ungültiger Inventarindex: " + index
        );
    }

    private static boolean matchesCategory(
            ItemStack stack,
            String category
    ) {
        if ("empty".equals(category)) {
            return stack.isEmpty();
        }

        if (stack.isEmpty()) {
            return false;
        }

        return classify(stack).equals(category);
    }

    private static String classify(ItemStack stack) {
        if (stack.isEmpty()) {
            return "empty";
        }

        String id = BuiltInRegistries.ITEM
                .getKey(stack.getItem())
                .getPath()
                .toLowerCase(Locale.ROOT);

        if (id.contains("sword")) return "sword";
        if (id.endsWith("_axe")) return "axe";
        if (id.endsWith("_pickaxe")) return "pickaxe";
        if (id.endsWith("_shovel")) return "shovel";
        if (id.equals("water_bucket")) return "water";
        if (id.equals("ender_pearl")) return "pearls";

        if (stack.get(DataComponents.FOOD) != null) {
            return "food";
        }

        if (stack.getItem() instanceof BlockItem) {
            return "blocks";
        }

        return "other";
    }
}
