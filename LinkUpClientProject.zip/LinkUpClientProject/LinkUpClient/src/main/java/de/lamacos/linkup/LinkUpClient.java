
package de.lamacos.linkup;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class LinkUpClient implements ClientModInitializer {

    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(
                    Identifier.fromNamespaceAndPath(
                            "linkupclient", "main"
                    )
            );

    private KeyMapping openMenuKey;
    private KeyMapping hudKey;
    private KeyMapping applyHotbarKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.linkupclient.open_menu",
                        InputConstants.Type.KEYBOARD,
                        InputConstants.getKey(
                                "key.keyboard.right.shift"
                        ).getValue(),
                        CATEGORY
                )
        );

        hudKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.linkupclient.hud",
                        InputConstants.Type.KEYBOARD,
                        InputConstants.KEY_J,
                        CATEGORY
                )
        );

        applyHotbarKey = KeyMappingHelper.registerKeyMapping(
                new KeyMapping(
                        "key.linkupclient.apply_hotbar",
                        InputConstants.Type.KEYBOARD,
                        InputConstants.KEY_H,
                        CATEGORY
                )
        );

        HotbarLayoutManager.load();
        LinkUpHudScreen.loadSavedPosition();

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath(
                        "linkupclient", "mini_hud"
                ),
                (graphics, deltaTracker) -> {
                    var client =
                            net.minecraft.client.Minecraft.getInstance();

                    if (client.player != null) {
                        LinkUpHudScreen.renderHud(
                                graphics,
                                client,
                                LinkUpHudScreen.isEditingMode()
                        );
                    }
                }
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                client.gui.setScreen(new LinkUpMenuScreen());
            }

            while (hudKey.consumeClick()) {
                if (client.player == null) {
                    continue;
                }

                if (client.options.keyShift.isDown()) {
                    HotbarLayoutManager.save(client.player);
                } else if (LinkUpHudScreen.isEditingMode()) {
                    LinkUpHudScreen.setEditingMode(false);
                    client.gui.setScreen(null);
                } else if (client.gui.getClass() != null) {
                    LinkUpHudScreen.setEditingMode(true);
                    client.gui.setScreen(new LinkUpHudScreen());
                }
            }

            while (applyHotbarKey.consumeClick()) {
                if (client.player != null
                        && client.options.keyShift.isDown()) {
                    HotbarLayoutManager.apply(client.player);
                }
            }
        });

        System.out.println("[LinkUp Client] Initialisiert!");
    }
}
